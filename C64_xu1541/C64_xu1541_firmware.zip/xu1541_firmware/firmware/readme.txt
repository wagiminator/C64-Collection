Short version (Linux):
======================
avrdude -c usbtiny -p atmega8 -U lfuse:w:0x9f:m -U hfuse:w:0xc8:m -U flash:w:bootldr-usbtiny.hex
sudo ./xu1541_update firmware.hex



Long version:
=============

Installing the BIOS (for the first time)
----------------------------------------
avrdude -c usbtiny -p atmega8 -U lfuse:w:0x9f:m -U hfuse:w:0xc8:m -U flash:w:bootldr-avrusb.hex
or
avrdude -c usbtiny -p atmega8 -U lfuse:w:0x9f:m -U hfuse:w:0xc8:m -U flash:w:bootldr-usbtiny.hex

Two versions of the BIOS exist. Both provide the same functionality but are based on
different AVR usb implementations. It shouldn't make a difference which version you use.
But if you encounter problems it may be worth giving the other version a try. Please report
such incompatibilities.


Flashing the firmware
---------------------
Once the BIOS is installed, it can be used to easily install the firmware itself via USB. In
order to install the firmware on a BIOS equipped xu1541 the following steps are required:
Plug in the xu1541, if it is not already. If there is no firmware on the xu1541, the LED
will go on and stay on. If there is already a firmware on the xu1541, the LED will go
on for a fraction of a second, and go off afterwards.
Use the upload tool with latest firmware: make update-firmware
or run the already compiled program xu1541_update
