flash firmware without bootloader
=================================
avrdude -c usbasp -p m644p -U flash:w:sd2iec-1.0.0atentdead0-24-ga9a09fa-larsp-m644p.bin:a
avrdude -c usbasp -p m644p -U hfuse:w:0x91:m -U lfuse:w:0xef:m -U efuse:w:0xfd:m

Remove SD-Card before flashing!!!
